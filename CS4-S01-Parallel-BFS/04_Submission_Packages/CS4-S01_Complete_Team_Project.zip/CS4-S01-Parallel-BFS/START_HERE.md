# CS4-S01 Parallel BFS - complete team project

Start with `01_Common/README.md` (build, test, run, reproduce), `01_Common/CHECKLIST.md` (audit + what you must still do)
and each student's `CONTRIBUTION.md` in `02_Lucky_Sequential_BFS/` and `03_Girlfriend_OpenMP_BFS/`.

## Honest status (details in 01_Common/CHECKLIST.md)
* The measurements (`01_Common/data/raw/bfs_raw.csv`, 588 runs) were taken on a 4-vCPU Intel Xeon **cloud VM running Linux**, not on a Windows PC (`01_Common/data/env/environment.json`).
* Verified when this package was built, on an extracted copy of the ZIP (Linux, g++ 13.3): `make` without warnings; `make test` = 1402 checks passed, 0 failed; `analyze.py` reproduces the shipped derived CSV;
  `audit.py --docs` recomputes all metrics independently and finds the numbers in the Word tables consistent with the CSV (results in `01_Common/logs/audit_report.txt`).
* **Not verified:** compilation on native Windows or in WSL (no Windows machine available); the Word files were checked with python-docx and LibreOffice only (open them in Word before submitting);
  several reference DOIs/volumes are marked CHECK in `01_Common/REFERENCES.md`; no GPU version; no SNAP/SuiteSparse graphs.

## Placeholders still to fill in (left intact on purpose - no personal detail was invented)
* Word documents: `[Name, Reg. No.]` and `[Batch ID]` (report title block), `[Student N name, Reg. No.]` and `[ID]` (technical note headers, appendix headers).
* CSV ID columns: `STUDENT1`, `STUDENT2`, `BATCH_TBD` (see 01_Common/CHECKLIST.md for a one-line `sed` command that changes only those columns).

## Extracting on Windows 10 / 11
1. Download `CS4-S01_Complete_Team_Project.zip` and save it somewhere with a short path, for example `C:\Users\<you>\Documents\`.
2. Right-click the ZIP -> **Extract All...** -> choose a destination -> **Extract** (do not run files from inside the ZIP preview).
3. Open the extracted `CS4-S01-Parallel-BFS` folder. Start with `START_HERE.md`, then `01_Common\README.md`. To build and run the code use **WSL2/Ubuntu** (instructions in `01_Common/README.md`).
