Lucky_Sequential_BFS.zip and Girlfriend_OpenMP_Parallel_BFS.zip are the two standalone submission packages.
This folder (04_Submission_Packages) holds them; the master archive CS4-S01_Complete_Team_Project.zip is the whole project folder you are looking at.
