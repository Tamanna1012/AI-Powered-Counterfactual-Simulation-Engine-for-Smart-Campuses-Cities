# Lucky_Sequential_BFS - package information

**Owner:** Student 1 (Lucky): sequential BFS baseline

Student 2's note and appendix are deliberately not included; her source code (`03_Girlfriend_OpenMP_BFS/bfs_par*`) is included only because the shared tests, experiment runner and speedup analysis need it.

Both standalone packages contain the same integrated report (`01_Common/CS4-S01_Integrated_Report.docx`, identical byte for byte), the same data, plots, scripts and shared code. Only the individual technical note, appendix and the contribution description differ.

## Honest status (details in 01_Common/CHECKLIST.md)
* The measurements (`01_Common/data/raw/bfs_raw.csv`, 588 runs) were taken on a 4-vCPU Intel Xeon **cloud VM running Linux**, not on a Windows PC (`01_Common/data/env/environment.json`).
* Verified when this package was built, on an extracted copy of the ZIP (Linux, g++ 13.3): `make` without warnings; `make test` = 1402 checks passed, 0 failed; `analyze.py` reproduces the shipped derived CSV;
  `audit.py --docs` recomputes all metrics independently and finds the numbers in the Word tables consistent with the CSV (results in `01_Common/logs/audit_report.txt`).
* **Not verified:** compilation on native Windows or in WSL (no Windows machine available); the Word files were checked with python-docx and LibreOffice only (open them in Word before submitting);
  several reference DOIs/volumes are marked CHECK in `01_Common/REFERENCES.md`; no GPU version; no SNAP/SuiteSparse graphs.

## Placeholders still to fill in (left intact on purpose - no personal detail was invented)
* Word documents: `[Name, Reg. No.]` and `[Batch ID]` (report title block), `[Student N name, Reg. No.]` and `[ID]` (technical note headers, appendix headers).
* CSV ID columns: `STUDENT1`, `STUDENT2`, `BATCH_TBD` (see 01_Common/CHECKLIST.md for a one-line `sed` command that changes only those columns).

## Extracting on Windows 10 / 11
1. Download `Lucky_Sequential_BFS.zip` and save it somewhere with a short path, for example `C:\Users\<you>\Documents\`.
2. Right-click the ZIP -> **Extract All...** -> choose a destination -> **Extract** (do not run files from inside the ZIP preview).
3. Open the extracted `Lucky_Sequential_BFS` folder. Start with `02_Lucky_Sequential_BFS\CONTRIBUTION.md`, then `01_Common\README.md`. To build and run the code use **WSL2/Ubuntu** (instructions in `01_Common/README.md`).

## Files in this package
```
    .gitignore
    01_Common/CHECKLIST.md
    01_Common/CS4-S01_Integrated_Report.docx
    01_Common/Common_Source_Code_Appendix.docx
    01_Common/Makefile
    01_Common/README.md
    01_Common/REFERENCES.md
    01_Common/bench_common.hpp
    01_Common/bfs_tests.cpp
    01_Common/data/derived/bfs_derived.csv
    01_Common/data/derived/summary_table.csv
    01_Common/data/env/environment.json
    01_Common/data/raw/bfs_raw.csv
    01_Common/graph.hpp
    01_Common/logs/audit_report.txt
    01_Common/logs/correctness_test_output.txt
    01_Common/logs/run_experiments_stdout.txt
    01_Common/notes/VIVA_PREP.md
    01_Common/plots/fig1_time_vs_size.png
    01_Common/plots/fig2_speedup_vs_threads.png
    01_Common/plots/fig3_throughput_vs_density.png
    01_Common/plots/fig4_speedup_vs_size.png
    01_Common/plots/fig5_efficiency_vs_threads.png
    01_Common/plots/fig6_overhead_breakdown.png
    01_Common/plots/fig7_work_per_level_vs_speedup.png
    01_Common/requirements.txt
    01_Common/scripts/analyze.py
    01_Common/scripts/audit.py
    01_Common/scripts/build_appendices.py
    01_Common/scripts/build_docs.py
    01_Common/scripts/make_packages.py
    01_Common/scripts/plot.py
    01_Common/scripts/run_experiments.py
    01_Common/tests/cases/binary_tree7.expected
    01_Common/tests/cases/binary_tree7.graph
    01_Common/tests/cases/complete5.expected
    01_Common/tests/cases/complete5.graph
    01_Common/tests/cases/cycle6.expected
    01_Common/tests/cases/cycle6.graph
    01_Common/tests/cases/disconnected.expected
    01_Common/tests/cases/disconnected.graph
    01_Common/tests/cases/dup_selfloop.expected
    01_Common/tests/cases/dup_selfloop.graph
    01_Common/tests/cases/grid3x3.expected
    01_Common/tests/cases/grid3x3.graph
    01_Common/tests/cases/isolated_source.expected
    01_Common/tests/cases/isolated_source.graph
    01_Common/tests/cases/path5.expected
    01_Common/tests/cases/path5.graph
    01_Common/tests/cases/path5_mid.expected
    01_Common/tests/cases/path5_mid.graph
    01_Common/tests/cases/single.expected
    01_Common/tests/cases/single.graph
    01_Common/tests/cases/star6.expected
    01_Common/tests/cases/star6.graph
    01_Common/tests/cases/two_routes.expected
    01_Common/tests/cases/two_routes.graph
    02_Lucky_Sequential_BFS/CONTRIBUTION.md
    02_Lucky_Sequential_BFS/Student1_Source_Code_Appendix.docx
    02_Lucky_Sequential_BFS/Technical_Note_Student1.docx
    02_Lucky_Sequential_BFS/bfs_seq.hpp
    02_Lucky_Sequential_BFS/bfs_seq_main.cpp
    03_Girlfriend_OpenMP_BFS/CONTRIBUTION.md
    03_Girlfriend_OpenMP_BFS/bfs_par.hpp
    03_Girlfriend_OpenMP_BFS/bfs_par_main.cpp
```
